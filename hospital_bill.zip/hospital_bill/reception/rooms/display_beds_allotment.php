<?php
require_once("../../database.php");
$data = json_decode(file_get_contents("php://input"));
$patient_id=$data->patient_id;
$sql="SELECT * FROM beds_allotment ba,patient_registration pr,room_category rc,ward w,beds b where ba.bed_id=b.bed_id and ba.ward_id=w.ward_id and ba.room_id=rc.room_id and ba.patient_id=pr.patient_id and b.ward_id=w.ward_id and pr.patient_id='{$patient_id}' and ba.to_date IS NULL";


	$res=mysqli_query($con,$sql) or die(mysqli_error($con));
	$room=array();
	$row = mysqli_fetch_array($res);
	  $date = $row['from_date'];
	 /* $date1=(explode("_",$date));
	  $now = time(); // or your date as well
		$your_date = strtotime($date1[0]);
		$datediff = $now - $your_date;
		*/
		$currdate=date("Y-m-d");
		
        $datetime1 = new DateTime($date);
		$datetime2 = new DateTime($currdate);
		$interval = $datetime1->diff($datetime2);
		$number_of_days=$interval->format('%a');
		$room['patient_id'] = $row['patient_id'];
	  $room['room_id'] = $row['room_id'];
	  $room['patient_name'] = $row['patient_name'];
	  $room['room_name'] = $row['room_name'];
	  $room['ward_name'] = $row['ward_name'];
	  $room['ward_id'] = $row['ward_id'];
	  $room['bed_id'] = $row['bed_id'];
	  $room['from_date'] = $row['from_date'];
	  $room['floor'] = $row['floor'];
	  $room['number_of_days'] = $number_of_days; 
	  
	
	print json_encode($room);



?>