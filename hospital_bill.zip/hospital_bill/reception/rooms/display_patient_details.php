<?php
require_once("../../database.php");
$data = json_decode(file_get_contents("php://input"));
$patient_id=$data->patient_id;
$patient=array();
//current_date

$indate=date("Y-m-d");
date_default_timezone_set("Asia/Calcutta");
$intime= date("h:i:sa");
$date_time = $indate."_".$intime;
//

$sql="select * from beds_allotment ba,patient_registration pr,room_category rc,ward w,beds b where ba.patient_id='{$patient_id}' and ba.patient_id=pr.patient_id and ba.ward_id=w.ward_id and ba.bed_id=b.bed_id and b.status= 1";

	$res=mysqli_query($con,$sql) or die(mysqli_error($con));
	$patient=array();
	$row = mysqli_fetch_array($res); 
	  $patient['bed_id'] = $row['bed_id'];
	  $patient['ward_id'] = $row['ward_id'];
	  $patient['ward_name'] = $row['ward_name'];
	  $patient['room_id'] = $row['room_id'];
	  $patient['room_name'] = $row['room_name'];
	  $patient['patient_id'] = $row['patient_id'];
	  $patient['patient_name'] = $row['patient_name'];
	  $patient['from_date'] = $row['from_date'];
	  $patient['floor'] = $row['floor'];
	   $date = $row['from_date'];
	  $currdate=date("Y-m-d");
		
        $datetime1 = new DateTime($date);
		$datetime2 = new DateTime($currdate);
		$interval = $datetime1->diff($datetime2);
		$number_of_days=$interval->format('%a');
	 $patient['to_date'] = $currdate;
	 $patient['number_of_days'] = $number_of_days;
	
	print json_encode($patient);



?>