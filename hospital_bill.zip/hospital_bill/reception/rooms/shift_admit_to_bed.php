<?php
require_once("../../database.php");
$data = json_decode(file_get_contents("php://input"));
$bed_id=$data->bed_id;
$ward_id=$data->ward_id;
$room_id=$data->room_id;
$patient_id=$data->patient_id;
$payment=$data->payment;


if(isset($data->pay_mode))
$pay_mode=$data->pay_mode;


if(isset($data->amount))
$amount=$data->amount;
else
$amount=$data->price;


date_default_timezone_set("Asia/Calcutta");
$indate=date("Y-m-d");


$sql_insert="INSERT INTO beds_allotment (bed_id,ward_id,room_id,patient_id,from_date) VALUES ('{$bed_id}','{$ward_id}','{$room_id}','{$patient_id}','{$indate}')";
$res=mysqli_query($con,$sql_insert) or die(mysqli_error($con));
$update="UPDATE beds SET status=1 WHERE bed_id='{$bed_id}' and ward_id='{$ward_id}'";
$update_result=mysqli_query($con,$update) or die(mysqli_error($con));
 /* if($payment=="pay_now")
  {
	  $sql="INSERT INTO make_payment (patient_id,date,payment_mode,amount) VALUES  ('{$bed_id}','bed','{$patient_id}','{$date_time}', '{$pay_mode}','{$amount}')";
	  $result=mysqli_query($con,$sql);
  }
  else
  {
	   $sql="INSERT INTO make_payment (des_id,des_name,patient_id,payment_date,payment_mode,amount) VALUES  ('{$bed_id}','bed','{$patient_id}','{$date_time}', '{$payment}','{$amount}')";
	  $result=mysqli_query($con,$sql);
  }*/



?>