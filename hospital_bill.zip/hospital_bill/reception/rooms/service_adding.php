<?php
require_once("../../database.php");
$data = json_decode(file_get_contents("php://input"));
for($i=0;$i<sizeof($data);$i++)
{
$service_id[]=$data[$i]->service_id;
$price[]=$data[$i]->price;
$patient_id[]=$data[$i]->patient_id;

date_default_timezone_set("Asia/Calcutta");
$currdate=date("Y-m-d");


 $sql="INSERT INTO service_taken (patient_id,service_id,curr_date,amount) VALUES  ('{$patient_id[$i]}','{$service_id[$i]}','{$currdate}','{$price[$i]}')";
	  $result=mysqli_query($con,$sql);
}
?>