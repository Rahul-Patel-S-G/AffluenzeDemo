var app = angular.module('login', []);

app.controller('loginCtrl', ['$scope', '$http', function ($scope, $http) {
        // scope variables
       
		
				
				$scope.login = function () {
					
			    $http({     
						                method : 'POST' ,
										url: 'login.php',
										data: $scope.user
										
								}).success(function(data){
										$scope.patient_details=data;
									//	$window.location.href = "../admin/lab/index.html";

										
									
							         
						       }).error(function(data, status) {
						                 alert("error");
					   });
					
					
					};
					
				
	
     
}]);

