var app = angular.module('reception', []);

app.controller('reception_controller', ['$scope', '$http', function ($scope, $http) {
        // scope variables
        $scope.display_category={};
		 $scope.totalamt=0;
		$scope.add_category={};
		$scope.edit_category={};
        $scope.admit_show_category=false;
        $scope.admit_show_beds=false;
		$scope.shift_show_patient_category=false;
		$scope.shift_select_show=false;
		$scope.shift_show_category=false;
        $scope.shift_show_bed=false;
        $scope.show_dischagre_patient=false;   		
        $scope.admit_patient_show=true;   		
        $scope.shift_patient_show=false;   		
        $scope.discharge_patient_show=false;   		
				
			 $scope.shift_patient = function() {
			    
						$scope.admit_patient_show=false;   		
        $scope.shift_patient_show=true;   		
        $scope.discharge_patient_show=false; 
			 
			 };
			 $scope.discharge_patient = function() {
			 
						$scope.admit_patient_show=false;   		
        $scope.shift_patient_show=false;   		
        $scope.discharge_patient_show=true; 
			 
			 }; 
			 
			 $scope.admit_patient = function() {
			 
						$scope.admit_patient_show=true;   		
        $scope.shift_patient_show=false;   		
        $scope.discharge_patient_show=false; 
			 
			 };
		
		
		//on load funtions
		
		$http.get("display_roomtype.php")
                .success(function(data){
				      
                    $scope.display_room_type = data;
					 
                })
                .error(function() {
                    $scope.data = "error in fetching data";
                });
		
		
		// on click funtions
		
		// display room_type
        $scope.room_type = function() {
						 
							
						
						$http({     
						                method : 'POST' ,
										url: 'display_room_category.php',
										data: {roomid:$scope.roomid}
										
								}).success(function(data){
							            
										 $scope.admit_show_category=true;	
										$scope.display_room_category = data;
										angular.element('#add_category').modal('hide');
							            
						       }).error(function(data, status) {
						                 alert("error");
					   }); 
	    };

		//select beds
         $scope.shows_beds = function(ward_id) {
                   
                                 				    
													$http.post("show_beds.php",{ward_id : ward_id})
														.success(function(data,status,headers,config){
														  
														   $scope.beds_shows = data;
														  
														    $scope.admit_show_beds=true;
														}).error(function(data, status) {
														   alert("error");
													   });  
      };		

       //admit patient
	   
	   
		$scope.admit = function(bed_id,room_id,ward_id) {
		
		              alert("coming");
						
					  $http.post("admit_patient.php",{ward_id : ward_id,bed_id : bed_id,room_id : room_id})
					  .success(function(data){
									    alert(data); 
										console.log(data);
										$scope.patient_admit = data;
										
										angular.element('#edit_category').modal('hide');
							
						       }).error(function(data, status) {
						                 alert("error");
					   });
					   $http.get("display_doctor.php")
                .success(function(data){
				     
                    $scope.display_doctor = data;
					 
                })
                .error(function() {
                    $scope.data = "error in fetching data";
                });
				 
				 $http.get("display_insurance.php")
								.success(function(data){
									 
									$scope.display_insurance = data;
									
								})
								.error(function() {
									$scope.data = "error in fetching data";
								});
	
        };
		
		//	payment mode
		
		  $scope.paymentmode=false;
		 $scope.paynow = function() {
		          
		  $scope.paymentmode=true;
		 
		 };
		 
		 $scope.add_to_acc=function(){
			  $scope.paymentmode=false;
		 }
		   
		// admit to bed
	      $scope.admit_to_bed = function() {
								 
								
								
                              $http({     
						                method : 'POST' ,
										url: 'admit_to_bed.php',
										data: $scope.patient_admit
							  }).success(function(data,status,headers,config){
								      alert(data);
									  alert("Patient Admited");
									  
									  angular.element('#admitpatient').modal('hide');
													  $scope.room_type() ;					 
														   $scope.shows_beds($scope.ward_id);
					   
							}).error(function(data, status) {
								   alert("error");
													   });  
      };
	  
	  
	
		
		//shift patient
		
		 $scope.$watch('a.b', function () {
       
            //alert('newValue = ' + $scope.a.b);
			
			
			$http({     
						                method : 'POST' ,
										url: 'display_beds_allotment.php',
										data:{patient_id: $scope.a.b}
										
								}).success(function(data){
									   $scope.shift_show_patient_category=true;
									  $scope.display_bed_allot=data;
										
						       }).error(function(data, status) {
						                 alert("error");
					   });
        //do something
    });
	
	
	//
	
		$scope.display_beds = function(room_id) {
						
		             
					  $http.post("display_beds.php",{room_id : room_id})
						.success(function(data,status,headers,config){
							  
							$scope.display_beds = data;
							 
							
						})
						.error(function() {
							$scope.data = "error in fetching data";
						});  
				 
				 
	
        };
		
		
	   
	   
	  //  shift display room_type
        $scope.dis_room_type = function() {
						$http.get("display_roomtype.php")
                .success(function(data){
				     
                    $scope.shift_display_room_type = data;
					 
					$scope.shift_select_show=true;
                })
                .error(function() {
                    $scope.data = "error in fetching data";
                });
	    };
		//shift patient
		
		 $scope.$watch('service.patient_id', function () {
       
           
			
			
			$http({     
						                method : 'POST' ,
										url: 'patient_name.php',
										data:{patient_id: $scope.service.patient_id}
										
								}).success(function(data){
									   $scope.shift_show_patient_category=true;
									  $scope.name_of_patient=data;
										
						       }).error(function(data, status) {
						                 alert("error");
					   });
        //do something
    });
	
	
		// display room category
        $scope.shift_room_type = function() {
						 
								
						
						$http({     
						                method : 'POST' ,
										url: 'display_room_category.php',
										data: {roomid:$scope.room_id}
										
								}).success(function(data){
							              
										$scope.shift_display_room_category = data;
										
							            $scope.shift_show_category=true;
						       }).error(function(data, status) {
						                 alert("error");
					   }); 
	    };

		//select beds
         $scope.shift_shows_beds = function(ward_id) {
                   
                                 				    
													$http.post("show_beds.php",{ward_id : ward_id})
														.success(function(data,status,headers,config){
														 
														   $scope.shift_beds_shows = data;
														   
														   $scope.shift_show_bed=true;
														}).error(function(data, status) {
														   alert("error");
													   });  
      };		

       //admit patient
	   
	   
		$scope.shift_admit = function(bed_id,room_id,ward_id) {
		
		              
					  $http.post("admit_patient.php",{ward_id : ward_id,bed_id : bed_id,room_id : room_id})
					  .success(function(data){
									    
										$scope.shift_patient_admit = data;
										
							
						       }).error(function(data, status) {
						                 alert("error");
					   });
					   $http.get("display_doctor.php")
                .success(function(data){
				    
                    $scope.shift_display_doctor = data;
				 
                })
                .error(function() {
                    $scope.data = "error in fetching data";
                });
				  
				 
	
        };
		
		//	payment mode
		
		  $scope.paymentmode=false;
		 $scope.paynow = function() {
		          
		  $scope.paymentmode=true;
		 
		 };
		 
		 $scope.add_to_acc=function(){
			  $scope.paymentmode=false;
		 }
		   
		// admit to bed
	      $scope.shift_admit_to_bed = function() {
								 
								
								
							 $http({     
						                method : 'POST' ,
										url: 'shift_patient.php',
										data: $scope.display_bed_allot
							  }).success(function(data,status,headers,config){
								      
									  
									  
									 
							}).error(function(data, status) {
								   alert("error");
													   });  
		
							 $http({     
						                method : 'POST' ,
										url: 'shift_admit_to_bed.php',
										data: $scope.shift_patient_admit
							  }).success(function(data,status,headers,config){
								      alert(data);
									  alert("Patient Admited");
									  
									  angular.element('#shiftpatient').modal('hide');
							}).error(function(data, status) {
								   alert("error");
													   });  
      };
	// discharge patient
		// display patient_display
        $scope.patient_display = function() {
						 
						
						$http({     
						                method : 'POST' ,
										url: 'display_patient_details.php',
										data: {patient_id:$scope.dpatient_id}
										
								}).success(function(data){
							             
										$scope.display_patient_details = data;
										 
										$scope.show_dischagre_patient=true;		
						       }).error(function(data, status) {
						                 alert("error");
					   });
	    };
	
		
		
   // add services
     $http.get("display_service.php")
                .success(function(data){
				    
                    $scope.display_service = data;
					
                })
                .error(function() {
                    $scope.data = "error in fetching data";
                });
   
   // display service_price
        $scope.service_price = function() {
					 
								
						
						$http({     
						                method : 'POST' ,
										url: 'display_service_price.php',
										data: {service_id:$scope.service.list_service}
										
								}).success(function(data){
							             
										$scope.display_service_price = data;
										 		            
						       }).error(function(data, status) {
						                 alert("error");
					   });
	    };
		
		
		// add temp service
		   $scope.disp_service=[];
		   $scope.add_temp_service = function() {
			    $scope.show_div = true;
				 $http({     
						                method : 'POST' ,
										url: 'service_name.php',
										data: {service_id:$scope.service.list_service}
										
								}).success(function(data){
							            
										$scope.ser_name = data;
										 	$scope.disp_service.push({patient_id:$scope.service.patient_id,service_id :$scope.service.list_service,price : $scope.display_service_price.price,service_name:$scope.ser_name.service_name});
												$scope.service="";
												
						       }).error(function(data, status) {
						                 alert("error");
					   });
		        
				
						  
		};
		$scope.delete_temp_service = function(name) {
			    
		        $scope.disp_service.splice(name);
						  
		};

   
	// add service_details
	    	$scope.services_add={};
        $scope.service_add_details = function() {
						$scope.services_add=$scope.disp_service;
                      	
						
						
								
						
						$http({     
						                method : 'POST' ,
										url: 'service_adding.php',
										data: $scope.services_add
										
								}).success(function(data){
							             
										 angular.element('#addpatientservice').modal('hide');
										 		            
						       }).error(function(data, status) {
						                 alert("error");
					   });
	
		};
		
		
		//report of service
		 // display service_details
        $scope.show_service_details = function() {
						 
								
						
						$http({     
						                method : 'POST' ,
										url: 'service_details_show.php',
										data: {patient_id:$scope.patient_id}
										
								}).success(function(data){
							              
										$scope.display_service_show = data;
										 				            
						       }).error(function(data, status) {
						                 alert("error");
					   });
	    };
		 // display service_details
		 
        $scope.discharge = function() {
						 
								$http({     
						                method : 'POST' ,
										url: 'dischagre_patient.php',
										data: $scope.display_patient_details
							  }).success(function(data,status,headers,config){
								     var total=0; 
										
									 $scope.discharge_patient = data;
									 	for(var i in data){
											
										   total += parseInt(data[i][4],10);
										   
										}
                                        $scope.totalamt=total;
									 /* $http({     
												method : 'POST' ,
												url: 'discharge.php',
												data: $scope.display_patient_details
										
								          }).success(function(data){
										
											
									
                                        									
										console.log($scope.discharge_patient);
										setTimeout(function(){
													var innerContents = document.getElementById("printdischarge").innerHTML;
														var popupWinindow = window.open('', '_blank', 'width=600,height=700,scrollbars=no,menubar=no,toolbar=no,location=no,status=no,titlebar=no');  
														popupWinindow.document.open();
														popupWinindow.document.write('<html><head><link rel="stylesheet" type="text/css" href="style.css" /></head><body onload="window.print()">' + innerContents + '</html>');
														popupWinindow.document.close();		

											},500);
										}).error(function(data, status) {
						                 alert("error");
								}); */
									  
									 
							}).error(function(data, status) {
								   alert("error");
							});
						
						
	    };
		$scope.final_patient_details={};
		$scope.personal_details={};
		
		
		  $scope.finalprint = function() {
			  
			           	
						$http({     
						                method : 'POST' ,
										url: 'getpatient_details.php',
										data: $scope.display_patient_details
										
								}).success(function(data){
			                          	$scope.personal_details=data;
										console.log($scope.personal_details);
						 
								}).error(function(data, status) {
								alert("error");
								
								});
						
						$http({     
						                method : 'POST' ,
										url: 'discharge_patient_final.php',
										data: $scope.display_patient_details
										
								}).success(function(data){
							             var total=0; 
										
									 $scope.final_patient_details = data;
								
									 	for(var i in data){
											
										   total += parseInt(data[i][4],10);
										   
										}
                                        $scope.totalamt=total;
										setTimeout(function(){
													var innerContents = document.getElementById("printdischarge").innerHTML;
														var popupWinindow = window.open('', '_blank', 'width=600,height=700,scrollbars=no,menubar=no,toolbar=no,location=no,status=no,titlebar=no');  
														popupWinindow.document.open();
														popupWinindow.document.write('<html><head><link rel="stylesheet" type="text/css" href="style.css" /></head><body onload="window.print()">' + innerContents + '</html>');
														popupWinindow.document.close();		

											},500);
										
										 				            
						       }).error(function(data, status) {
						                 alert("error");
					   });
	    };
		
		
	
     
}]);




