var app = angular.module('user_lab', []);

app.controller('user_lab_controller', ['$scope', '$http', function ($scope, $http) {
        // scope variables
		$scope.tests = {};
		$scope.test_name = {};
		$scope.total = 0;
		$scope.total1 = 0;
		$scope.totalprice=0;
		
		$scope.show_test = false;
		$scope.show_package = false;
    $scope.click = function() {
		$scope.show_package = false;
			$scope.show_test = true;
			$http.get("category_type.php")
                .success(function(data){
				     //alert(data);
                    $scope.test_category_details = data;
					//console.log($scope.display_test);
				
                })
                .error(function() {
                    $scope.data = "error in fetching data";
                });
			
	}; 
	$scope.click_package = function() {
		$scope.show_test = false;
		$scope.show_package = true;

			
	};
	//on load funtions
		//display test
	   $http.get("display_test.php")
                .success(function(data){
				     //alert(data);
                    $scope.display_test = data;
					//console.log($scope.display_test);
				
                })
                .error(function() {
                    $scope.data = "error in fetching data";
                });
// display package
				$http.get("display_package.php")
                .success(function(data){
				
                    $scope.display_package = data;
					console.log($scope.display_package);
				
                })
                .error(function() {
                    $scope.data = "error in fetching data";
                });
				
				//check list of package
				
				$scope.addCheck = function (test) {
					if(test.checked) {
						$scope.tests[test.test_id] = test;
						$scope.total+=parseInt(test.price);
						
						//console.log($scope.tests);
					}
					else {
						
						delete $scope.tests[test.test_id];
						$scope.total-=parseInt(test.price);
						//console.log($scope.tests);
					}
					
				}
				$scope.caloffer=function(offer){
				
				         var offer_given=parseInt(offer);
	                     $scope.totalprice=$scope.total;					
				         $scope.offerprice= parseFloat(offer/100) * $scope.totalprice ;
						 $scope.totalprice= parseFloat($scope.total-$scope.offerprice);
						 
				
				}
				//check list of test
				
				$scope.addtest = function (test_name) {
				
					if(test_name.checked) {
					
						$scope.test_name[test_name.test_id] = test_name.test_name;
					
						$scope.total1+=parseInt(test_name.price);
						console.log($scope.test_name);
					}
					else {
						
						
						delete $scope.test_name[test_name.test_id];
						$scope.total1-=parseInt(test_name.price);
						console.log($scope.test_name);
					}
					
				}
				$scope.caloffer=function(offer){
				
				         var offer_given=parseInt(offer);
	                     $scope.totalprice=$scope.total;					
				         $scope.offerprice= parseFloat(offer/100) * $scope.totalprice ;
						 $scope.totalprice= parseFloat($scope.total-$scope.offerprice);
				
				}
			 // edit package
        $scope.package_edit = function(package_id) {
						$scope.package_id=package_id;
					//	alert($scope.package_id);
						 $http.post("edit_package.php",{package_id : $scope.package_id})
						
										
								.success(function(data){
							             //alert(data);
										 console.log(data);
								
										 $scope.total=data.totalprice;
										$scope.edit_package = data;
										
							            
						       }).error(function(data, status) {
						                 alert("error");
					   }); 
					   $http.post("list_test.php",{package_id : $scope.package_id})
						.success(function(data){
							           //  alert(data);
										 console.log(data);
										$scope.list_test = data;
										
						       }).error(function(data, status) {
						                 alert("error");
					   });  
	    };

		
		
		$scope.print_op_lab=function(packade_id){
		
		         $http({     
						                method : 'POST' ,
										url:'lab_screen_print.php',
										data:{ package_id:$scope.edit_package.package_id, patient_id:$scope.patient_id, paymentmode: $scope.paymentmode, flag:$scope.flag,amount:$scope.total}
												
						}).success(function(data){
							      
										 console.log(data);
										$scope.screen_print = data;
										
									  setTimeout(function(){
														var innerContents = document.getElementById("packageprintsection").innerHTML;
														var popupWinindow = window.open('', '_blank', 'width=600,height=700,scrollbars=no,menubar=no,toolbar=no,location=no,status=no,titlebar=no');  
														popupWinindow.document.open();
														popupWinindow.document.write('<html><head><link rel="stylesheet" type="text/css" href="style.css" /></head><body onload="window.print()">' + innerContents + '</html>');
														popupWinindow.document.close();		

											},500);
											
											$scope.show_package = false;
							            
						       }).error(function(data, status) {
						                 alert("error");
					   }); 
				
		
		};
		
		
		// edit package
        $scope.print_screen = function(patient_id) {
        
		
						$http({     
						                method : 'POST' ,
										url:'print_screen.php',
										data:{testnames:$scope.test_name, patient_id:patient_id, paymentmode: $scope.paymentmode, flag:$scope.flag,amount:$scope.total1}
												
						}).success(function(data){
							             
										 console.log(data);
										$scope.screen_print = data;
										
									  setTimeout(function(){
														var innerContents = document.getElementById("printsection").innerHTML;
														var popupWinindow = window.open('', '_blank', 'width=600,height=700,scrollbars=no,menubar=no,toolbar=no,location=no,status=no,titlebar=no');  
														popupWinindow.document.open();
														popupWinindow.document.write('<html><head><link rel="stylesheet" type="text/css" href="style.css" /></head><body onload="window.print()">' + innerContents + '</html>');
														popupWinindow.document.close();		

											},500);
												$scope.show_test = false;
											
							            
						       }).error(function(data, status) {
						                 alert("error");
					   }); 
									
	    };
		
	// test _display 
	$scope.test_display=function()
	{
		
		$http({     
						                method : 'POST' ,
										url: 'test_display_category.php',
										data: {test_cat_id : $scope.category.test_cat_id }
										
								}).success(function(data){
							          
									 
										
										$scope.display_test = data;
										$scope.show_test=true;
							            
						       }).error(function(data, status) {
						                 alert("error");
					   });  
		
	}
	
	
     
}]);

