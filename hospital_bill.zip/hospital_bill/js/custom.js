
$(document).ready(function(){
$("#more").click(function(){
	$(".more-option").toggleClass("hidden");
});


});

$('#uploadfile').click(function(){

    alert("hello" );

    $('#uploadbtn').click();


});