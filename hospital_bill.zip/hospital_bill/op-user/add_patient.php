<?php


	require_once("../database.php");
	
	
	$data = json_decode(file_get_contents("php://input"));
	$name=$data->patient_name;
	if(isset($data->date_of_birth))
	$dob=$data->date_of_birth;
	else
	$dob="";
	$email=$data->email;
	$phone=$data->phone;
	$age=$data->age;
	$gender=$data->gender;
	$address=$data->address;
   
	


	
	//insert
	$sql="insert into patient_registration ( patient_name, phone, email, dob, age, gender, address) values('{$name}','{$phone}','{$email}','{$dob}','{$age}','{$gender}','{$address}')";
	$res=mysqli_query($con,$sql) or die(mysqli_error($con));
	

	
	//select id	
	$sql="select patient_id from patient_registration where phone = '{$phone}' ";
	$res=mysqli_query($con,$sql) or die(mysqli_error($con));
	$row=mysqli_fetch_array($res);
	
	$actual_id=$row['patient_id'];
	$id="PATIENT-".$row['patient_id'];
	


	//include "test_barcode.php"; 

	// set Barcode39 object 
	//$bc = new Barcode39($id); 

	// display new barcode 
	$barcode="Blob data";

	$update="update patient_registration set barcode_reader= '{$id}' where patient_id='{$actual_id}' ";


	$result=mysqli_query($con,$update) or die(mysqli_error($con));

	
	$sql="select * from patient_registration where patient_id ='{$actual_id}' ";
	$res=mysqli_query($con,$sql) or die(mysqli_error($con));
	$data=array();
	$row=mysqli_fetch_array($res);
	$data['patient_id']=$row['patient_id'];
	
	
	print json_encode($data);
	

?>


